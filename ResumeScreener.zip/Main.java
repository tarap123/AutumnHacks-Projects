import java.io.*;

class Main {
  public static void main(String[] args) throws Exception {
    System.out.println();
    System.out.println("WELCOME TO RESUME SCREENER");
    System.out.println();
    System.out.println("To begin...Please make sure you paste your resume into the .txt file");
    System.out.println();
    System.out.println("_____________________");
    System.out.println("Calculating results based on your resume...");
    System.out.println();

    int cyber_count = 0;
    int electricalEng_count = 0;
    int aerospaceEng_count = 0;
    int softDev_count = 0;
    int aiEng_count = 0;
    int vidGame_count = 0;

    // Cybersecurity career
    String[] cyber_keyWords = { "cybersecurity", "cyber", "security", "cloud", "protection", "malware", "darkweb",
        "firewall", "CS", "VPN", "IP", "virus", "bot", "spyware", "encryption", "encrypted", "decryption",
        "decrypted" };
    String[] electricalEng_keyWords = { "electrical engineering", "engineering", "automation", "electronics",
        "technical", "troubleshooting", "autocad", "electricity", "control systems", "matlab" };
    String[] aerospaceEng_keyWords = { "aerospace engineering", "solidworks", "aircrafts", "mechanical engineering",
        "cad", "computer aided design", "simulation", "airplane", "space" };
    String[] softDev_keyWords = { "software engineering", "develop", "java", "python", "software development",
        "computer science", "cs", "database", "javascript", "html", "programming", "git", "debugging", "mysql" };
    String[] aiEng_keyWords = { "ai", "artificial intelligence", "solution", "data acquisition", "analysis",
        "machine learning", "deep learning", "tensorflow", "nlp", "algorithms", "ai engineer" };
    String[] vidGame_keyWords = { "game", "game development", "games", "video game", "user interface design",
        "innovation", "apple", "ios", "android", "development", "video game developer" };
    try {
      BufferedReader reader = new BufferedReader(new FileReader("test_1.txt"));
      String line = reader.readLine();
      while (line != null) {
        for (int i = 0; i < cyber_keyWords.length; i++) {
          if (line.contains(cyber_keyWords[i])) {
            // do something
            cyber_count++;
          }
        }
        for (int j = 0; j < electricalEng_keyWords.length; j++) {
          if (line.contains(electricalEng_keyWords[j])) {
            // do something
            electricalEng_count++;
          }
        }
        for (int k = 0; k < aerospaceEng_keyWords.length; k++) {
          if (line.contains(aerospaceEng_keyWords[k])) {
            // do something
            aerospaceEng_count++;
          }
        }
        for (int l = 0; l < softDev_keyWords.length; l++) {
          if (line.contains(softDev_keyWords[l])) {
            // do something
            softDev_count++;
          }
        }
        for (int m = 0; m < aiEng_keyWords.length; m++) {
          if (line.contains(aiEng_keyWords[m])) {
            // do something
            aiEng_count++;
          }
        }
        for (int n = 0; n < vidGame_keyWords.length; n++) {
          if (line.contains(vidGame_keyWords[n])) {
            // do something
            vidGame_count++;
          }
        }

        line = reader.readLine();
      }
      if (electricalEng_count > cyber_count && electricalEng_count > aerospaceEng_count
          && electricalEng_count > softDev_count && electricalEng_count > aiEng_count
          && electricalEng_count > vidGame_count) {
        System.out.println("You should apply for a career in Electrical Engineering.");

      } else if (cyber_count > electricalEng_count && cyber_count > aerospaceEng_count && cyber_count > softDev_count
          && cyber_count > aiEng_count && cyber_count > vidGame_count) {
        System.out.println("You should apply for a career in Cybersecurity.");
      } else if (aerospaceEng_count > cyber_count && aerospaceEng_count > electricalEng_count
          && aerospaceEng_count > softDev_count && aerospaceEng_count > aiEng_count
          && aerospaceEng_count > vidGame_count) {
        System.out.println("You should apply for a career in Aerospace Engineering.");
      } else if (softDev_count > cyber_count && softDev_count > electricalEng_count
          && softDev_count > aerospaceEng_count && softDev_count > aiEng_count && softDev_count > vidGame_count) {
        System.out.println("You should apply for a career in Software Development.");
      } else if (aiEng_count > cyber_count && aiEng_count > electricalEng_count && aiEng_count > aerospaceEng_count
          && aiEng_count > softDev_count && aiEng_count > vidGame_count) {
        System.out.println("You should apply for a career in AI Engineering.");
      } else {
        System.out.println("You should apply for a career in Video Game Development.");
      }
    } catch (Exception ex) {
      System.out.println(ex.getMessage());
    }

  }
}